#! /bin/sh
${srcdir}/out_test.sh coff_test modules/objfmts/coff/tests "coff objfmt" "-f coff" ".o"
exit $?
